var express = require('express');
var app = express();// framework used in node js. node js is a platform
var fs = require("fs");
// endpoint : filter : http://localhost:name/firstname
//http://localhost:name/lastname
app.get('/listUsers', function (req, res) {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      console.log( data );
      res.end( data );
   });
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})