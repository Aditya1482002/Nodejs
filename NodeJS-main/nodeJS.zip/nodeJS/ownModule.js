exports.myDateTime = function () //export statement makes the function or the module eligible to be reused
{
    return Date();//this function returns today's date
  };