var x=10;
var y=20;
var z=(x+y)*30;//simple
console.log(z);
var math=require('mathjs');//importung the internal module to perform complex mathematical operations
math.pow(2,3);